# Azeroth Servers backup script
# -----------------------------
# This script saves the main directories structure, all the AzerothCore databases
# definitions and data (*.sql), the scripts and the configuration files to a 7z
# file into the backup directory and copies it to the remote backup directory.

echo -e "\e[42;30m   *** Backing up servers ***                                                         \e[0m"

source $(dirname $0)/access_config.sh

echo -e "\e[1;31mCompressing\e[0m..."
cd $root_dir
touch backup/.0 logs/.0 data/.0
cd ..
filename=$(date +"%Y-%m-%d_%H-%M-%S")_servers.7z
fullfilename=$local_backup_dir/$filename
7z a $fullfilename -t7z -mx=9 .bash_aliases wotlk/backup/.0 wotlk/data/.0 wotlk/logs/.0 wotlk/media/* wotlk/scripts/* wotlk/server/etc/* wotlk/docs/*

echo -e "\e[1;31mCopying to remote backup folder: \e[1;33m$filename\e[0m..."
gcp $fullfilename $remote_backup_dir

echo -e "\e[1;36mDone\e[0m."
echo ""
sleep 3
