# Azeroth Servers install binaries script
# ---------------------------------------

source $(dirname $0)/access_config.sh

echo -e "Type '\e[1;31mok\e[0m' to install \e[1;33mAzerothCore-WotLK\e[0m binaries."
read answer
if [ $answer = ok ]
then

   echo -e "\e[1;31mCopying old distribution config files\e[0m..."
   cd $root_dir/server/etc/
   cp authserver.conf.dist authserver.conf.dist.old
   cp worldserver.conf.dist worldserver.conf.dist.old
   cp modules/transmog.conf.dist modules/transmog.conf.dist.old

   echo -e "\e[1;31mMake install\e[0m..."
   cd $root_dir/azerothcore/build
   make install

   echo -e "\e[1;36mDone\e[0m."
   echo -e "Now you should be able to run the servers, but you should check the configuration files first."

fi
