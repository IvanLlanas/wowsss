# WoW server command line
# -----------------------
# This script performs several functions related to AzerothCore World of Warcraft
# server maintenance.

source $(dirname $0)/access_config.sh

# ANSI codes
_0="\e[0m"
_r="\e[1;31m"
_w="\e[1;37m"
_bb="\e[1;94m"
_g="\e[1;92m"
_cy="\e[1;96m"
_y="\e[1;93m"
_m="\e[1;95m"

# cmd is the first argument.
cmd=$1

if [ $# -eq 0 ]
  then
    echo "No arguments supplied."
    cmd=status
fi

# lcmd is the length of the first argument (or the default function).
lcmd=${#cmd}

# cmd help ----------------------------------------------------------------------
if [[ $lcmd -gt 0 && "help" == $cmd* ]]
   then
   echo WoW commands:
   echo ""
   echo -e "  "wow $_m""help$_0"            - "Shows this help.
   echo -e "  "wow $_m""version$_0"         - "Shows the servers version string.
   echo ""
   echo -e "  "wow $_w""start$_0"           - "Starts the servers.
   echo -e "  "wow $_w""stop$_0"            - "Stops the servers.
   echo -e "  "wow $_w""status$_0"          - "Shows the servers status.
   echo ""
   echo -e "  "wow $_g""save$_0"            - "Saves auth and characters databases.
   echo -e "  "wow $_g""save $_y""all$_0"        - "Saves databases, servers and sources.
   echo -e "  "wow $_g""save $_y""databases$_0"  - "Saves auth, characters and world databases.
   echo -e "  "wow $_g""save $_y""sources$_0"    - "Saves the servers sources.
   echo -e "  "wow $_g""save $_y""servers$_0"    - "Saves the servers files and scripts.
   echo -e "  "wow $_g""save $_y""data$_0"       - "Saves the world map data files.
   echo ""
   echo -e "  "wow $_cy""download$_0"        - "Deletes the current sources and downloads the latest ones "(git)".
   echo -e "  "wow $_cy""update$_0"          - "Updates the current sources "(git)".
   echo -e "  "wow $_bb""make$_0"            - "Compiles the current sources and builds the servers binaries.
   echo -e "  "wow $_bb""install$_0"         - "Installs the servers binaries.
   echo ""
   exit
fi

# cmd version -------------------------------------------------------------------
if [[ $lcmd -gt 0 && "version" == $cmd* ]]
   then
   echo -en $_w
   cat $root_dir/docs/welcome.txt
   echo -en $_0
   exit
fi

# cmd status --------------------------------------------------------------------
if [[ $lcmd -gt 3 && "status" == $cmd* ]]
   then
   echo -en $_w
   ps -f -C worldserver -C authserver
   echo -en $_0
   exit
fi

# cmd start ---------------------------------------------------------------------
if [[ $lcmd -gt 3 && "start" == $cmd* ]]
   then
   $root_dir/scripts/start-servers.sh
   exit
fi

# cmd stop ----------------------------------------------------------------------
if [[ $lcmd -gt 2 && "stop" == $cmd* ]]
   then
   $root_dir/scripts/stop-servers.sh
   exit
fi

# cmd download ------------------------------------------------------------------
if [[ $lcmd -gt 2 && "download" == $cmd* ]]
   then
   $root_dir/scripts/download-full-sources.sh
   exit
fi

# cmd update --------------------------------------------------------------------
if [[ $lcmd -gt 2 && "update" == $cmd* ]]
   then
   $root_dir/scripts/update-git.sh
   exit
fi

# cmd make ----------------------------------------------------------------------
if [[ $lcmd -gt 3 && "make" == $cmd* ]]
   then
   $root_dir/scripts/make-servers.sh
   exit
fi

# cmd update --------------------------------------------------------------------
if [[ $lcmd -gt 3 && "install" == $cmd* ]]
   then
   $root_dir/scripts/make-install.sh
   exit
fi

# cmd ip ------------------------------------------------------------------------
if [[ $lcmd -gt 1 && "ip" == $cmd* ]]
   then
   hostname -I
   exit
fi

# cmd save ----------------------------------------------------------------------
if [[ $lcmd -gt 3 && "save" == $cmd* ]]
   then
   cmd=$2
   lcmd=${#cmd}

   # save all --------------------------
   if [[ "" == $cmd ]]
      then
      $root_dir/scripts/backup-databases.sh
      exit
   fi
   # save all --------------------------
   if [[ "all" == $cmd ]]
      then
      $root_dir/scripts/backup-all.sh
      exit
   fi
   # save databases -------------------
   if [[ "databases" == $cmd ]]
      then
      $root_dir/scripts/backup-databases-full.sh
      exit
   fi
   # save sources ----------------------
   if [[ "sources" == $cmd ]]
      then
      $root_dir/scripts/backup-sources.sh
      exit
   fi
   # save servers ----------------------
   if [[ "servers" == $cmd ]]
      then
      $root_dir/scripts/backup-servers.sh
      exit
   fi
   # save data -------------------------
   if [[ "data" == $cmd ]]
      then
      $root_dir/scripts/backup-data.sh
      exit
   fi

   cmd="$_w""save $_y$cmd"
fi

# cmd is not recognized ---------------------------------------------------------
echo -e $_r""ERROR: Unknown command \'$_y""$cmd$_r\'.$_0
