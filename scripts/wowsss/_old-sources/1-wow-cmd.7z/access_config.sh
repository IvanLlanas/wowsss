# Aliases  (just in case they are not created in .bash_aliases)
# alias xcp="rsync --progress"

# MariaDB/MySQL user and password
db_user="root"
db_pass="1234"

# Root directory.
root_dir="/home/wow/wotlk"

# Scripts directory.
sh_dir="$root_dir/scripts"

# Backup directories (must not end with "/")
local_backup_dir="$root_dir/backup"
remote_backup_dir="$local_backup_dir/remote"

# Machine type "detection".
case $HOSTNAME in
 "azeroth-v" )   machine='vmware';;
 "azeroth-i" )   machine='i5';;
 "azeroth-is")   machine='isard';;
 "azeroth-pi")   machine='r-pi';;
            *)   echo -e "\e[101;93m[ WARNING! Unknown hostname: unknown machine type. ]\e[0m";
                 machine='?';;
esac
#echo $machine
