# AzerothCore-WotLK update script
# -------------------------------

source /etc/lsb-release
source $(dirname $0)/access_config.sh

echo -e "Type '\e[1;31mok\e[0m' to update \e[1;33mAzerothCore-WotLK\e[0m from GIT."
read answer
if [ $answer = ok ]
then

   # For AzerothCore-WotLK:
   echo Checking AzerothCore updates...
   cd $root_dir/azerothcore/
   git pull origin master
   # For Mod-Transmog:
   echo Checking TransMog updates...
   cd $root_dir/azerothcore/modules/mod-transmog/
   git pull origin master

   TEXT="AzerothCore-WotLK $(date +"%Y/%m/%d %H:%M:%S") - $DISTRIB_DESCRIPTION ($HOSTNAME / $machine)"
   echo $TEXT >> $root_dir/docs/history.txt
   echo $TEXT >  $root_dir/docs/welcome.txt
   echo ""    >> $root_dir/docs/welcome.txt

   echo -e "\e[1;36mNow you can execute script \e[1;93m'scripts/make-servers.sh'\e[1;36m or:"
   echo -e " 1 - go to \e[1;93m'azerotcore/build'\e[1;36m"
   echo -e " 2 - execute the \e[1;93mcmake\e[1;36m long command line and"
   echo -e " 3 - \e[1;93mmake\e[1;36m the servers."
   echo -e "You'll finally need to \e[1;93m'make install'\e[1;36m to move the new servers to their place.\e[0m"

else

   echo -e "\e[1;36mQuitting\e[0m."

fi
