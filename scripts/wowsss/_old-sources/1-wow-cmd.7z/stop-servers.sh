# Azeroth Servers stopping script
# -------------------------------

# pidof authserver >/dev/null && echo "Server is running" || echo "Server NOT running"

if pidof authserver >/dev/null 
then
   echo Shutting down authserver...
   killall -e authserver -w
else
   echo Authserver is NOT running.
fi

if pidof worldserver >/dev/null
then
   echo Shutting down worldserver...
   killall -e worldserver -w
else
   echo Worldserver is NOT running.
fi

echo Done.
sleep 3

