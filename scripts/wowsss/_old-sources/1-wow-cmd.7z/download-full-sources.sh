# Azeroth Servers sources download and cmake script
# -------------------------------------------------

source /etc/lsb-release
source $(dirname $0)/access_config.sh

echo -e "Type '\e[1;31mok\e[0m' to download (not updating) \e[1;33mAzerothCore-WotLK\e[0m (with modules)."
read answer
if [ $answer = ok ]
then

   cd $root_dir
   rm azerothcore -Rf
   git clone https://github.com/azerothcore/azerothcore-wotlk.git --branch master --single-branch azerothcore
   cd $root_dir/azerothcore/modules
   git clone https://github.com/azerothcore/mod-transmog.git
   cd ..
   mkdir build
   cd build
   cmake ../ -DCMAKE_INSTALL_PREFIX=$HOME/wotlk/server/ -DCMAKE_C_COMPILER=/usr/bin/clang -DCMAKE_CXX_COMPILER=/usr/bin/clang++ -DWITH_WARNINGS=1 -DTOOLS_BUILD=maps-only -DSCRIPTS=static -DMODULES=static
   echo -e "Now you should \"\e[1;33mmmake\e[0m\", \"\e[1;33mmake install\e[0m\" to finish the installation. You can also use \e[1;33mmake-servers.sh\e[0m and \e[1;33mmake-install.sh\e[0m scripts."

   TEXT="AzerothCore-WotLK $(date +"%Y/%m/%d %H:%M:%S") - $DISTRIB_DESCRIPTION ($HOSTNAME / $machine)"
   echo $TEXT >> $root_dir/docs/history.txt
   echo $TEXT >  $root_dir/docs/welcome.txt
   echo ""    >> $root_dir/docs/welcome.txt

fi
