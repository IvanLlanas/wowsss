echo -e "\e[44;97m   *** Backing up all ***                                                             \e[0m"
echo ""

source $(dirname $0)/access_config.sh

cd $root_dir/azerothcore/build/
make clean

cd $sh_dir
time ./backup-databases-full.sh
echo ""

time ./backup-servers.sh
echo ""

time ./backup-sources.sh
echo ""
