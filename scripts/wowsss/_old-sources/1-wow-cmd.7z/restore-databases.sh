source $(dirname $0)/access_config.sh

cd /home/wow/wotlk/scripts/sql

echo -e "Importing \"\e[1;33macore_auth\e[0m\" database:"
mysql -u $db_user -p acore_auth       < acore_auth.sql

echo -e "Importing \"\e[1;32macore_characters\e[0m\" database:"
mysql -u $db_user -p acore_characters < acore_characters-full.sql

echo -e "Importing \"\e[1;34macore_world\e[0m\" database:"
mysql -u $db_user -p acore_world      < acore_world.sql

echo -e "\e[1;36mFinished\e[0m."
echo ""
