# Azeroth Servers databases backup script
# ---------------------------------------
# This script saves all the AzerothCore databases definitions and data (*.sql)
# to a 7z file into the backup directory and copies it to the remote backup
# directory.

echo -e "\e[42;30m   *** Backing up databases (full) ***                                                \e[0m"

source $(dirname $0)/access_config.sh
cd $local_backup_dir

echo -e "Extracting \e[1;33macore_auth\e[0m..."
mysqldump --user=$db_user --password=$db_pass acore_auth > acore_auth.sql

echo -e "Extracting \e[1;32macore_characters\e[0m..."
mysqldump --user=$db_user --password=$db_pass acore_characters > acore_characters-full.sql
mysqldump --user=$db_user --password=$db_pass acore_characters > acore_characters-structure.sql --no-data
mysqldump --user=$db_user --password=$db_pass acore_characters > acore_characters-data.sql      --no-create-info

echo -e "Extracting \e[1;34macore_world\e[0m..."
mysqldump --user=$db_user --password=$db_pass acore_world > acore_world.sql

echo -e "\e[1;31mCompressing\e[0m..."
filename=$(date +"%Y-%m-%d_%H-%M-%S")_databases_full.7z
fullfilename=$local_backup_dir/$filename
7z a $fullfilename -t7z -mx=9 -sdel acore_auth*.sql acore_characters*.sql acore_world*.sql

echo -e "\e[1;31mCopying to remote backup folder: \e[1;33m$filename\e[0m..."
gcp $fullfilename $remote_backup_dir

echo -e "\e[1;36mDone\e[0m."
echo ""
sleep 3
