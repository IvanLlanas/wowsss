# Script to start the servers from "Startup applications".
#---------------------------------------------------------

gnome-terminal --title "Start servers" -- bash -c "/home/wow/wotlk/scripts/start-servers.sh"

