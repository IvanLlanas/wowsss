# Azeroth Servers data backup script
# ----------------------------------
# This script compresses the server data files, inside data directory, to a
# file into the backup directory and copies it to the remote backup directory.

echo -e "\e[41;97m   *** Backing up data folder ***                                                     \e[0m"

source $(dirname $0)/access_config.sh

filename=$(date +"%Y-%m-%d_%H-%M-%S")_data.7z
fullfilename=$local_backup_dir/$filename

echo -e "\e[1;31mCompressing\e[0m..."
cd $root_dir
7z a $fullfilename -t7z -mx=9 data/*

echo -e "\e[1;31mCopying to remote backup folder: \e[1;33m$filename\e[0m..."
gcp $fullfilename $remote_backup_dir

echo -e "\e[1;36mDone\e[0m."
echo ""
sleep 3
