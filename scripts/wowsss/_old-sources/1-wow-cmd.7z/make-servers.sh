# Azeroth Servers make/build binaries script
# ------------------------------------------

source $(dirname $0)/access_config.sh

echo -e "Type '\e[1;31mok\e[0m' to build \e[1;33mAzerothCore-WotLK\e[0m (with modules)."
read answer
if [ $answer = ok ]
then

   filename=$root_dir/docs/history.txt
   cd $root_dir/azerothcore/build
   cmake ..
   make clean
   echo "   "--- >> $filename
   echo "   "Started at  $(date +"%Y/%m/%d %H:%M:%S") >> $filename
   make -j $(nproc --all)
   echo "   "Finished at $(date +"%Y/%m/%d %H:%M:%S") >> $filename
   echo "   "--- >> $filename

   echo -e "\e[1;36mDone\e[0m."
   echo -e "After a succesful build a \"\e[1;33mmake clean\e[0m\" or \"\e[1;33mmake install\e[0m\" is required to finish the installation. You should instead use \e[1;33mmake-install.sh\e[0m script or \e[1;33mwow install\e[0m to, additionally, backup old distribution configuration files."

fi
