# Azeroth Servers starting script
# -------------------------------
if pidof authserver >/dev/null 
then
   echo "Server(s) already running."
   sleep 3
   exit
else
   if pidof worldserver >/dev/null 
   then
      echo "Server(s) already running."
      sleep 3
      exit
   fi
fi

gnome-terminal --tab --title "AuthServer" -- bash -c "/home/wow/wotlk/server/bin/authserver"
sleep 2
gnome-terminal --tab --title "WorldServer" -- bash -c "/home/wow/wotlk/server/bin/worldserver"
sleep 3
