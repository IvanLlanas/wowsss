# Azeroth Servers sources backup script
# -------------------------------------
# This script compresses the server source files, azerothcore directory, to a
# file into the backup directory and copies it to the remote backup directory.
# A make clean is performed before compressing the files.

echo -e "\e[42;30m   *** Backing up sources ***                                                         \e[0m"

source $(dirname $0)/access_config.sh

cd $root_dir/azerothcore/build/
make clean

echo -e "\e[1;31mCompressing\e[0m..."
cd $root_dir
filename=$(date +"%Y-%m-%d_%H-%M-%S")_sources.7z
fullfilename=$local_backup_dir/$filename
7z a $fullfilename -t7z -mx=9 azerothcore/. server/etc/*

echo -e "\e[1;31mCopying to remote backup folder: \e[1;33m$filename\e[0m..."
gcp $fullfilename $remote_backup_dir

echo -e "\e[1;36mDone\e[0m."
echo ""
sleep 3
