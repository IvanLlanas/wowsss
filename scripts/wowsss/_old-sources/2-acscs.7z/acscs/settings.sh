# ##############################################################################
# These values should be checked and updated by the user BEFORE running ACSCS.
# ##############################################################################

# Database server user and password to be used by ACSCS for the database
# management. It should be root.
DB_SCRIPT_USER=root
DB_SCRIPT_USER_PASSWORD=1234

# Database server user and password to be used by the AzerothCore servers.
# Used to update the new configuration files. It shouldn't be root.
DB_SERVERS_USER=acore
DB_SERVERS_USER_PASSWORD=1234

# Database names and hosts. Remote hosts not supported by ACSCS, yet.
DB_AUTH_NAME=acore_auth
DB_WORLD_NAME=acore_world
DB_CHARACTERS_NAME=acore_characters
DB_AUTH_HOST="127.0.0.1;3306"
DB_WORLD_HOST="127.0.0.1;3306"
DB_CHARACTERS_HOST="127.0.0.1;3306"

# Number of CPU cores to use on sources compilation. All by default.
CPU_CORES=$(nproc --all)

# Should backups be copied elsewhere?
REMOTE_BACKUPS=1
REMOTE_BACKUPS_DIR=$HOME/wotlk/backup/remote
