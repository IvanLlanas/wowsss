# ------------------------------------------------------------------------------
# function azerothcore_sources_download            ()
# function azerothcore_sources_update              ()
# function azerothcore_sources_compile_and_install ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Deletes the current AzerothCore sources. Downloads latest AzerothCore sources
# from Github and creates the make files.
# Returns non-zero on error.
# If $1 is non-zero this function will quit on error.
# ------------------------------------------------------------------------------
function azerothcore_sources_download ()
{
   local ac="azerothcore"
   local quit_on_error=$1
   local result=0

   cd $var_dir_base
   if test -d "$ac"; then
      show_info_message "$cons_msg_deleting_old_sources"
      rm "$ac" -Rf
   fi

   mkdir "$ac"
   show_info_message "$cons_msg_cloning_ac"
   git clone https://github.com/azerothcore/azerothcore-wotlk.git --branch master --single-branch "$ac"
   result=$?
   if [ $result -ne 0 ] ; then
      if [ $quit_on_error > 0 ]; then
         show_fatal_error "$cons_msg_error_dwnd_ac"
      else
         show_error_message "$cons_msg_error_dwnd_ac"
         return $result
      fi
   fi

   show_info_message "$cons_msg_cloning_transmog_mod"
   cd $var_dir_sources/modules
   git clone https://github.com/azerothcore/mod-transmog.git
   result=$?
   if [ $result -ne 0 ] ; then
      if [ $quit_on_error -gt 0 ]; then
         show_fatal_error "$cons_msg_error_dwnd_ac_mods"
      else
         show_error_message "$cons_msg_error_dwnd_ac_mods"
         return $result
      fi
   fi

   logs_update_server_version

   cd $var_dir_sources
   show_info_message "$cons_msg_creating_make_files"
   mkdir build
   cd build
   cmake ../ -DCMAKE_INSTALL_PREFIX=$var_dir_server/ -DCMAKE_C_COMPILER=/usr/bin/clang -DCMAKE_CXX_COMPILER=/usr/bin/clang++ -DWITH_WARNINGS=1 -DTOOLS_BUILD=maps-only -DSCRIPTS=static -DMODULES=static
   result=$?
   if [ $result -ne 0 ] ; then
      if [ $quit_on_error -gt 0 ]; then
         show_fatal_error "$cons_msg_error_creating_make_files"
      else
         show_error_message "$cons_msg_error_creating_make_files"
         return $result
      fi
   fi
   play_sound "$cons_snd_done1"
}

# ------------------------------------------------------------------------------
# Compiles and installs the servers sources and updates the log files.
# Makes backup of *.conf.dist files to check changes.
# ------------------------------------------------------------------------------
function azerothcore_sources_compile_and_install ()
{
   var_sources_just_compiled=

   # Add starting compiling time to history.txt.
   local filename=$var_dir_docs/history.txt
   cd $var_dir_sources/build
   cmake ..
   make clean
   echo "   "--- >> $filename
   echo "   "Started at  $(date +"%Y/%m/%d %H:%M:%S") >> $filename

   # Make!
   make -j $var_compiler_cores
   if [ $? -eq 0 ]; then
      var_sources_just_compiled=1
   fi

   # Add starting compiling time to history.txt.
   echo "   "Finished at $(date +"%Y/%m/%d %H:%M:%S") >> $filename
   echo "   "--- >> $filename

   if [[ $var_sources_just_compiled ]]; then
      # ------------------------------------------------------------------------
      # Installs the servers binaries and makes backup of *.conf.dist files to
      # check changes.
      # ------------------------------------------------------------------------
      show_info_message "$cons_msg_backing_up_dist_cfg_files"
      # Backup up previous *.conf.dist files to compare possible changes.
      cd $var_dir_server/etc
      cp authserver.conf.dist authserver.conf.dist.old
      cp worldserver.conf.dist worldserver.conf.dist.old
      cp modules/transmog.conf.dist modules/transmog.conf.dist.old

      # Make install
      show_info_message "$cons_msg_make_install"
      cd $var_dir_sources/build
      make install

      servers_setup_default_config_files
   fi
   play_sound "$cons_snd_done1"
   return $var_sources_just_compiled
}

# ------------------------------------------------------------------------------
# Updates the source code to its last push.
# ------------------------------------------------------------------------------
function azerothcore_sources_update ()
{
   # For AzerothCore-WotLK:
   show_info_message "cons_msg_checking_updates_for_"$_bold1"AzerothCore"$_bold2"..."
   cd $var_dir_sources
   git pull origin master
   if [ $? -eq 0 ]; then
      logs_update_server_version
   fi

   # For Mod-Transmog:
   show_info_message "cons_msg_checking_updates_for_"$_bold1"TransMog"$_bold2"..."
   cd $var_dir_sources/modules/mod-transmog/
   git pull origin master
   play_sound "$cons_snd_done1"
}
