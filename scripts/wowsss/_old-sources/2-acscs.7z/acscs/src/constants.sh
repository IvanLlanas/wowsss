# ------------------------------------------------------------------------------
# function declare_constants ()
# function declare_constants_var_dependent_on_variables ()
# ------------------------------------------------------------------------------

#define MAKE_SUCCESS 0
#define MAKE_TROUBLE 1
#define MAKE_FAILURE 2
# ------------------------------------------------------------------------------
function declare_constants ()
{
   cons_acscs_version="3.0"

   # ACSCS required software packages
   # --------------------------------
   cons_acscs_packages="git p7zip-full unzip gcp screen wget sox"

   # AzerothCore required software packages
   # --------------------------------------
   # https://www.azerothcore.org/wiki/linux-requirements
   # ACSCS will only focus on supporting only MariaDB. By now.
   # cons_ac_packages_ubuntu_mysql="cmake make gcc g++ clang libssl-dev libbz2-dev libreadline-dev libncurses-dev libboost-all-dev mysql-server libmysqlclient-dev"
   cons_ac_packages_ubuntu="cmake make gcc g++ clang libssl-dev libbz2-dev libreadline-dev libncurses-dev libboost-all-dev mariadb-server mariadb-client libmariadb-dev libmariadb-dev-compat"
   cons_ac_packages_debian="cmake make gcc g++ clang libssl-dev libbz2-dev libreadline-dev libncurses-dev libboost-all-dev mariadb-server default-libmysqlclient-dev"
   cons_ac_data_url="https://github.com/wowgaming/client-data/releases/download/v16/data.zip"

   # ANSI codes - Uncomment those being used.
   # ----------
   # https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797
   _ansi_0="\e[0m"
   _ansi_black="\e[30m"
   _ansi_red="\e[31m"
#  _ansi_green="\e[32m"
   _ansi_yellow="\e[33m"
#  _ansi_blue="\e[34m"
#  _ansi_magenta="\e[35m"
#  _ansi_teal="\e[36m"
#  _ansi_gray="\e[37m"
   _ansi_dark_gray="\e[90m"
   _ansi_lime="\e[92m"
   _ansi_yellow="\e[93m"
   _ansi_cyan="\e[96m"
   _ansi_white="\e[97m"
#  _ansi_magenta="\e[95m"
# Background Black: [40m
   _ansi_bg_red="\e[41m"
   _ansi_bg_green="\e[42m"
   _ansi_bg_yellow="\e[43m"
#  _ansi_bg_yellow_light="\e[103m"
   _ansi_bg_blue="\e[44m"
#  _ansi_bg_magenta="\e[45m"
#  _ansi_bg_cyan="\e[46m"
   _ansi_bg_white="\e[47m"
#  _ansi_blue2="\e[1;94m"

   _input_color=$_ansi_lime
   _disabled_color=$_ansi_dark_gray
   _menu_text_color=$_ansi_cyan

   # Messages
   _bold1='<b>'   # Bold text delimiter 1 - do not use spaces!
   _bold2='</b>'  # Bold text delimiter 1 - do not use spaces!

   cons_lit_host="Host"
   cons_lit_username="Username"
   cons_lit_base_directory="Base directory"
   cons_lit_finished="Finished"
   cons_lit_running="Running"
   cons_lit_stopped="Stopped"
   cons_lit_internal_ip="Internal IP"
   cons_lit_external_ip="External IP"
   cons_lit_installed_packages="Installed packages"
   cons_lit_configuring="Configuring"

   cons_msg_quitting="Quitting."
   cons_msg_unknown_linux_version="Unknown Linux version."
   cons_msg_installation_failed="Installation failed."
   cons_msg_checking_ac_sources="Checking "$_bold1"AzerothCore sources"$_bold2":"
   cons_msg_checking_databases="Checking "$_bold1"databases"$_bold2":"
   cons_msg_checking_data="Checking "$_bold1"data"$_bold2" directory:"
   cons_lit_checking_database="Checking database"
   cons_lit_creating_database="Creating database"
   cons_lit_cannot_create_db="Cannot create database"
   cons_msg_checking_acscs_req_packages="Checking "$_bold1"ACSCS"$_bold2" required packages:"
   cons_msg_checking_ac_req_packages="Checking "$_bold1"AzerothCore"$_bold2" required packages:"
   cons_msg_deleting_old_sources="Deleting old sources..."
   cons_msg_cloning_ac="Downloading "$_bold1"AzerothCore"$_bold2" sources..."
   cons_msg_cloning_transmog_mod="Downloading "$_bold1"TransMog"$_bold2" module..."
   cons_msg_creating_make_files="Creating "$_bold1"make"$_bold2" files..."
   cons_msg_error_dwnd_ac="Error downloading AzerothCore."
   cons_msg_error_dwnd_ac_mods="Error downloading AzerothCore modules."
   cons_msg_error_creating_make_files="Error creating make files."
   cons_msg_error_download_data="Could not download data files archive."
   cons_msg_error_extracting_data="Error extracting data files from archive."
   cons_msg_binaries_found="Server binaries found. Bypassing sources checking."
   cons_msg_done="Done."

   cons_msg_good_bye="Good bye!"
   cons_confirmation="ok"
   cons_msg_error_invalid_option_="Invalid option "
   cons_msg_type_ok_to_=" Type '"$_bold1"$cons_confirmation"$_bold2"' to "
   cons_msg_not_confirmed="Not confirmed."
   cons_msg_error_authserver_not_found=$_bold1"AuthServer"$_bold2" not found."
   cons_msg_error_worldserver_not_found=$_bold1"WorldServer"$_bold2" not found."
   cons_msg_error_authserver_running=$_bold1"AuthServer"$_bold2" already running."
   cons_msg_error_worldserver_running=$_bold1"WorldServer"$_bold2" already running."
   cons_msg_error_authserver_not_running=$_bold1"AuthServer"$_bold2" is NOT running."
   cons_msg_error_worldserver_not_running=$_bold1"WorldServer"$_bold2" is NOT running."
   cons_msg_starting_authserver="Starting "$_bold1"AuthServer"$_bold2"..."
   cons_msg_starting_worldserver="Starting "$_bold1"WorldServer"$_bold2"..."
   cons_msg_stopping_authserver="Shutting down "$_bold1"AuthServer"$_bold2"..."
   cons_msg_stopping_worldserver="Shutting down "$_bold1"WorldServer"$_bold2"..."
   cons_msg_copying_to_remote_="Copying to remote backup folder"
   cons_lit_extracting="Extracting"
   cons_lit_compressing="Compressing"
   cons_msg_compressing="Compressing..."
   cons_msg_cleaning="Cleaning..."
   cons_msg_checking_updates_for_="Checking update for "
   cons_msg_error_servers_running="Servers are running. Shut them down first before continuing."
   cons_msg_backing_up_dist_cfg_files="Backing up old "$_bold1"distribution config files"$_bold2"..."
   cons_msg_make_install="Make "$_bold1"install"$_bold2"..."
   cons_msg_db_access_granted="Access granted to database server."
   cons_msg_enter_option=" Enter option: "

   cons_msg_choose_an_option=" Please, choose an option:"
   cons_option_start_server="Start the servers"
   cons_option_stop_server="Stop the servers"
   cons_option_process_monitor="Process monitor"
   cons_option_restore_consoles="Restore authserver/worldserver console (^A^D)"
   cons_option_backup_databases="Save auth and characters databases"
   cons_option_backup_databases_world="Save world database"
   cons_option_backup_servers="Save servers files (binaries, sources and data directory excluded)"
   cons_option_backup_sources="Save current AzerothCore sources"
   cons_option_backup_data="Save data directory"
   cons_option_backup_all="Save all (data directory excluded)"
   cons_option_sources_download="Remove current sources and download them from github"
   cons_option_sources_update="Update current sources from github"
   cons_option_sources_compile="Compile and install servers and tools"
   cons_option_restore_databases="Restore databases"

   # Default wait seconds
   cons_wait_seconds=2

   # Application to play a sound file (ogg) and its command line parameters.
   cons_playsound="play -q"
   cons_playsound_params=""

   # Sound files
   cons_snd_error1="are-you-challenging-me.ogg"
   cons_snd_error2="thats-not-funny.ogg"
   cons_snd_error3="you-dispute-my-honor.ogg"
   cons_snd_done1="work-complete.ogg"
   cons_snd_ready1="lok-tar.ogg"
}

# ------------------------------------------------------------------------------
function declare_constants_var_dependent_on_variables ()
{
   cons_msg_error_db_cannot_access_server="Cannot access the database server. You should check the "$_bold1"DB_SCRIPT_USER"$_bold2" and "$_bold1"DB_SCRIPT_USER_PASSWORD"$_bold2" values in your $_bold1$var_script_path/settings.sh$_bold2 file or configure your database server ("$_bold1"mysql_secure_installation"$_bold2")."
   cons_msg_tips_setup_db_server_1="To configure your server with the values in your $_bold1$var_script_path/settings.sh$_bold2 file you can do:"
   cons_msg_tips_setup_db_server_2="   $ sudo mysql_secure_installation"
   cons_msg_tips_setup_db_server_3="   $ sudo mysqladmin -u $_bold1$var_db_user$_bold2 password $_bold1$var_db_pass$_bold1"
   cons_msg_tips_setup_db_server_4="   $ sudo mysqladmin -u $_bold1$var_db_user$_bold2 -h localhost password $_çbold1$var_db_pass$_bold1"
   cons_msg_db_access_granted_2="Access granted to user $_bold1$var_db_servers_user$_bold2 to database server."
   
   cons_msg_db_setup_0_message="In case this is a fresh installation I can do this for you. Otherwise, you must configure correctly your database server by yourself (recommended)."
   cons_msg_db_setup_0_option_1="   1 - Yes, please, make these changes for me and put my database server at risk."
   cons_msg_db_setup_0_option_2="   2 - Naah, thanks, I don't trust you, I'll do this myself."
   cons_msg_db_setup_0_confirmation="automatically setup the databases and the server"
}
