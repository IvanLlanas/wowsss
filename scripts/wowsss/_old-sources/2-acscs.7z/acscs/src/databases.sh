# ------------------------------------------------------------------------------
# function database_check_enable_admin_access ()
# function database_check_create_servers_access ()
# function databases_check_create()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Tries to configure the initial MariaDB access.
# ------------------------------------------------------------------------------
function _mysql_secure_installation ()
{
   show_info_message "sudo mysqladmin -u $var_db_user password "$var_db_pass""
   sudo mysqladmin -u $var_db_user password "$var_db_pass"
   sudo mysqladmin -u $var_db_user -h localhost password $var_db_pass

   # sudo mysql -e "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1')"
   # MariaDB:
   show_info_message "mysql -u $var_db_user -p1234 -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$var_db_pass'""
   mysql -u $var_db_user -p1234 -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$var_db_pass'"
   show_info_message "mysql -u $var_db_user -p1234 -e "FLUSH PRIVILEGES""
   mysql -u $var_db_user -p1234 -e "FLUSH PRIVILEGES"

   # Kill off the demo database
   # sudo mysql -e "DROP DATABASE IF EXISTS test"
   # Kill the anonymous users
   # sudo mysql -e "DROP USER ''@'localhost'"
   # Because our hostname varies we'll use some Bash magic here. Nope.
   # sudo mysql -e "DROP USER ''@'$(hostname)'"
}

# ------------------------------------------------------------------------------
# Check if database ($1) exists. If it does not exists it will try to create it.
# Quits on error.
# ------------------------------------------------------------------------------
function _database_check_create ()
{
   local db=$1
   local uparams="--user=$var_db_user --password=$var_db_pass"
   local query="USE $db"

   show_info_message "$cons_lit_checking_database $_bold1$db$_bold2..."

   mysql $uparams -e "$query" &> /dev/null
   result=$?
   if [ $result -ne 0 ]; then
      query="CREATE DATABASE \`$db\` DEFAULT CHARACTER SET UTF8MB4 COLLATE utf8mb4_general_ci"
      mysql $uparams -e "$query" &> /dev/null
      result=$?
      if [ $result -ne 0 ]; then
         show_fatal_error "$cons_lit_cannot_create_db $_bold1$db$_bold2."
      fi

      local host="localhost"
      local query="GRANT ALL PRIVILEGES ON \`$db\`.* TO '$var_db_servers_user'@'$host' WITH GRANT OPTION;"
      mysql $uparams -e "$query" &> /dev/null
   fi
}

# ------------------------------------------------------------------------------
# Checks if the databases game required databases exist and creates them if not.
# ------------------------------------------------------------------------------
function databases_check_create()
{
   _database_check_create "$var_db_auth_name"
   _database_check_create "$var_db_world_name"
   _database_check_create "$var_db_chars_name"
}

# ------------------------------------------------------------------------------
# Checks if we can access the database server with $var_db_user (root)
# and $var_db_pass. Quits on error.
# ------------------------------------------------------------------------------
function database_check_enable_admin_access ()
{
   # Can we login with var_db_user/var_db_pass?
   mysql -e "SHOW DATABASES" --user=$var_db_user --password=$var_db_pass &> /dev/null
   result=$?
   if [ $result -ne 0 ]
   then
      # Cannot access. Cannot continue until the server is properly configured.
      show_error_message "$cons_msg_error_db_cannot_access_server"
      show_info_message "$cons_msg_tips_setup_db_server_1"
      show_info_message "$cons_msg_tips_setup_db_server_2"
      show_info_message "$cons_msg_tips_setup_db_server_3"
      show_info_message "$cons_msg_tips_setup_db_server_4"

      show_warning_message "$cons_msg_db_setup_0_message"
      echo "$cons_msg_db_setup_0_option_1"
      echo "$cons_msg_db_setup_0_option_2"
      echo -n "$cons_msg_enter_option"
      read_answer
      case $var_answer in
       "1")   read_confirmation "$cons_msg_db_setup_0_confirmation"
              if [ $var_confirmed ]
                 then
                 _mysql_secure_installation
                 # Let's try again after _mysql_secure_installation. Recursive!!!
                 database_check_enable_admin_access
              else
                 show_fatal_error "$cons_msg_not_confirmed"
              fi
              ;;
         *)   show_info_message "Come back when you've configured the database server and checked the settings.sh file."
              exit
              ;;
      esac
   else
      show_info_message "$cons_msg_db_access_granted"
   fi
}

# ------------------------------------------------------------------------------
# Checks if we can access the database server with $var_db_servers_user (acore)
# and $var_db_servers_pass and/or creates and sets up the database user.
# ------------------------------------------------------------------------------
function database_check_create_servers_access ()
{
   local user_just_created=
   # Can we login with var_db_servers_user/var_db_servers_pass?
   mysql -e "SHOW DATABASES" --user=$var_db_servers_user --password=$var_db_servers_pass &> /dev/null
   result=$?
   if [ $result -ne 0 ]
   then
      # User does not exists or invalid values. Let's create it!
      local host="localhost"
      local queries="DROP USER IF EXISTS '$var_db_servers_user'@'$host';\
                      CREATE USER '$var_db_servers_user'@'$host' IDENTIFIED BY '$var_db_servers_pass' WITH MAX_QUERIES_PER_HOUR 0 MAX_CONNECTIONS_PER_HOUR 0 MAX_UPDATES_PER_HOUR 0;\
                      GRANT ALL PRIVILEGES ON \`$var_db_world_name\`.* TO '$var_db_servers_user'@'$host' WITH GRANT OPTION;\
                      GRANT ALL PRIVILEGES ON \`$var_db_chars_name\`.* TO '$var_db_servers_user'@'$host' WITH GRANT OPTION;\
                      GRANT ALL PRIVILEGES ON \`$var_db_auth_name\`.*  TO '$var_db_servers_user'@'$host' WITH GRANT OPTION;"
      mysql -e "$queries" --user=$var_db_user --password=$var_db_pass
      result=$?
      if [ $result -ne 0 ]
      then
         show_fatal_error "Cannot create database server user $_bold1$var_db_servers_user$_bold2."
      fi
      user_just_created=1
   else
      show_info_message "$cons_msg_db_access_granted_2"
   fi
}

