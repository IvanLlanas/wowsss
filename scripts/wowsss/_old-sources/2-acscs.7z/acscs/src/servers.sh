# ------------------------------------------------------------------------------
# function ensure_no_server_running ()
# function acscs_servers_start ()
# function acscs_servers_stop ()
# function acscs_top ()# function logs_update_server_version ()
# function servers_setup_default_config_files ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Checks if there's any of the servers running. If a server is running an error
# message is displayed and returns var_no_server_running set to true, false
# otherwise.
# ------------------------------------------------------------------------------
function ensure_no_server_running ()
{
   update_pidof_as
   update_pidof_ws
   if [ $var_pidof_auth ] || [ $var_pidof_worldserver ]
      then
      show_error_message "$cons_msg_error_servers_running"
      wait
      var_no_server_running=
   else
      var_no_server_running=1
   fi
}

# ------------------------------------------------------------------------------
# Adds a new line into docs/history.txt with the new server version and
# updates the docs/welcome.txt with the same text.
# ------------------------------------------------------------------------------
function logs_update_server_version ()
{
   # Add new "make" entry to history log and server version.
   vars_get_achash # Update the current hash.
   local text="AzerothCore-WotLK $(date +"%Y/%m/%d %H:%M:%S") ($var_achash) - $var_os_distribution ($var_os_hostname)"
   echo  $text >> $var_dir_docs/history.txt
   echo  $text >  $var_dir_docs/welcome.txt
   #echo ""    >> $var_dir_docs/welcome.txt
}

function server_version_no_date()
{
   local text="AzerothCore-WotLK ($var_achash) - $var_os_distribution ($var_os_hostname)"
   echo "$text"
}

# ------------------------------------------------------------------------------
# Menu option: Start the servers
function acscs_servers_start ()
{
   local auth_just_loaded=
   acscs_function_start "$cons_option_start_server"

   update_pidof_as
   update_pidof_ws

# Using "screen" to launch and retrieve the servers consoles.
# -A
#    Adapt the sizes of all windows to the size of the current terminal. By
#    default, screen tries to restore its old window sizes when attaching to
#    resizable terminals (those with WS in its description, e.g. suncmd or some
#    xterm).
# -m -d
#    Start screen in detached mode. This creates a new session but doesn't attach
#    to it. This is useful for system startup scripts.
# -S sessionname
#    When creating a new session, this option can be used to specify a meaningful
#    name for the  session. This name identifies the session for screen -list and
#    screen -r actions. It substitutes the default [tty.host] suffix. This name
#    should not be longer then 80 symbols.

   if [ $var_pidof_auth ]
   then
      show_error_message "$cons_msg_error_authserver_running"
   else
      local server="$var_dir_server/bin/authserver"
      if test -x "$server"; then
         show_info_message "$cons_msg_starting_authserver"
         # gnome-terminal --tab --title "AuthServer" -- bash -c "$var_dir_server/bin/authserver"
         # nohup "$var_dir_server/bin/authserver" > "$var_dir_logs/authserver.out" &
         # nohup "$var_dir_server/bin/authserver" > /dev/null &
         screen -AmdS  $var_session_auth  "$server"
         auth_just_loaded=1
      else
         show_error_message "$cons_msg_error_authserver_not_found"
      fi
      update_pidof_as
   fi

   if [ $var_pidof_worldserver ]
   then
      show_error_message "$cons_msg_error_worldserver_running"
   else
      if [ $auth_just_loaded ]
      then
         # Give a couple of seconds to start AuthServer before starting
         # WorldServer.
         sleep 2
      fi
      local server="$var_dir_server/bin/worldserver"
      if test -x "$server"; then
         show_info_message "$cons_msg_starting_worldserver"
         # gnome-terminal --tab --title "WorldServer" -- bash -c "$var_dir_server/bin/worldserver"
         # nohup "$var_dir_server/bin/worldserver" > "$var_dir_logs/worldserver.out" &
         # nohup "$var_dir_server/bin/worldserver" > /dev/null &
         screen -AmdS  $var_session_world  "$server"
      else
         show_error_message "$cons_msg_error_worldserver_not_found"
      fi
      update_pidof_ws
   fi

   acscs_function_end
}

# ------------------------------------------------------------------------------
# Menu option: Stop the servers
function acscs_servers_stop ()
{
   acscs_function_start "$cons_option_stop_server"

   update_pidof_as
   update_pidof_ws

   if [ $var_pidof_auth ]
   then
      show_info_message "$cons_msg_stopping_authserver"
      killall -e authserver -w
   else
      show_error_message "$cons_msg_error_authserver_not_running"
   fi

   if [ $var_pidof_worldserver ]
   then
      show_info_message "$cons_msg_stopping_worldserver"
      killall -e worldserver -w
   else
      show_error_message "$cons_msg_error_worldserver_not_running"
   fi

   update_pidof_as
   update_pidof_ws
   acscs_function_end
}

# ------------------------------------------------------------------------------
# Menu option: Process monitor
# ------------------------------------------------------------------------------
function acscs_top ()
{
   update_pidof_db
   update_pidof_as
   update_pidof_ws

   local cmd="top "

   if [ $var_pidof_db ]
      then
      cmd="$cmd -p $var_pidof_db"
   fi
   if [ $var_pidof_auth ]
      then
      cmd="$cmd -p $var_pidof_auth"
   fi
   if [ $var_pidof_worldserver ]
      then
      cmd="$cmd -p $var_pidof_worldserver"
   fi

   $cmd
   clear
}

# ------------------------------------------------------------------------------
# Menu option: Process monitor
# ------------------------------------------------------------------------------
function servers_setup_default_config_files ()
{
   local filename=
   local path=

   # Default *.conf files
   cd $var_dir_server/etc
   filename="authserver.conf"
   if [ ! -f "$filename" ]; then
      show_info_message "$cons_lit_configuring $filename..."
      cp $filename.dist $filename
      # sed -i "s/^${variable}\=.*/${variable}=\"${content}\"/" "${file}"
      # \s\{0,\} => any space
      path=${var_dir_logs//\//\\/}
      sed -i 's/LogsDir\s\{0,\}=.*/LogsDir = "'$path'"/' $filename
      path=${var_dir_temp//\//\\/}
      sed -i 's/TempDir\s\{0,\}=.*/TempDir = "'$path'"/' $filename

      sed -i 's/LoginDatabaseInfo\s\{0,\}=.*/LoginDatabaseInfo = "'$var_db_auth_host';'$var_db_servers_user';'$var_db_servers_pass';'$var_db_auth_name'"/' $filename
      
      show_warning_message $_bold1"$var_dir_server/etc/$filename$_bold2: This file has been automatically generated. You should check it out."
   fi

   filename="worldserver.conf"
   if [ ! -f "$filename" ]; then
      show_info_message "$cons_lit_configuring $filename..."
      cp $filename.dist $filename
      path=${var_dir_logs//\//\\/}
      sed -i 's/LogsDir\s\{0,\}=.*/LogsDir = "'$path'"/' $filename
      path=${var_dir_data//\//\\/}
      sed -i 's/DataDir\s\{0,\}=.*/DataDir = "'$path'"/' $filename
      path=${var_dir_temp//\//\\/}
      sed -i 's/TempDir\s\{0,\}=.*/TempDir = "'$path'"/' $filename

      sed -i 's/LoginDatabaseInfo\s\{0,\}=.*/LoginDatabaseInfo     = "'$var_db_auth_host';'$var_db_servers_user';'$var_db_servers_pass';'$var_db_auth_name'"/' $filename
      sed -i 's/WorldDatabaseInfo\s\{0,\}=.*/WorldDatabaseInfo     = "'$var_db_world_host';'$var_db_servers_user';'$var_db_servers_pass';'$var_db_world_name'"/' $filename
      sed -i 's/CharacterDatabaseInfo\s\{0,\}=.*/CharacterDatabaseInfo = "'$var_db_chars_host';'$var_db_servers_user';'$var_db_servers_pass';'$var_db_chars_name'"/' $filename
      show_warning_message $_bold1"$var_dir_server/etc/$filename$_bold2: This file has been automatically generated. You should check it out."
   fi

   filename="modules/transmog.conf"
   if [ ! -f "$filename" ]; then
      show_info_message "$cons_lit_configuring $filename..."
      cp $filename.dist $filename
      show_warning_message $_bold1"$var_dir_server/etc/$filename$_bold2: This file has been automatically generated. You should check it out."
   fi
}

