# ------------------------------------------------------------------------------
# function declare_variables ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
function declare_variables ()
{
   # Installation --------------------------------------------------------------

   # OS name and version
   var_os_hostname=$HOSTNAME
   if type lsb_release >/dev/null 2>&1; then
      # Get OS info from lsb_release
      var_os_name=$(lsb_release -si)
      var_os_version=$(lsb_release -sr)
      var_os_codename=$(lsb_release -sc)
      var_os_distribution="$var_os_name $var_os_version ($var_os_codename)"
      case $var_os_name in
        *"Ubuntu"*) var_os_is_ubuntu=1;;
        *"Debian"*) var_os_is_debian=1;;
        *) show_fatal_error "$cons_msg_unknown_linux_version";;
      esac
   else
      show_fatal_error "$cons_msg_unknown_linux_version"
   fi
   console_log_value "$var_os_hostname - $var_os_distribution" "$cons_lit_host"

   # Current user name and current user home directory
   var_os_username=$USER
   var_os_userid=$UID
   console_log_value "$var_os_username/$var_os_userid ($HOME)" "$cons_lit_username"

   # Amount of installed packages in installation phase.
   var_installed_packages=0

   # MariaDB/MySQL user and password for script management.
   var_db_user=$DB_SCRIPT_USER
   var_db_pass=$DB_SCRIPT_USER_PASSWORD

   # MariaDB/MySQL user and password for servers
   var_db_servers_user=$DB_SERVERS_USER
   var_db_servers_pass=$DB_SERVERS_USER_PASSWORD
   var_db_auth_name=$DB_AUTH_NAME
   var_db_auth_host=$DB_AUTH_HOST
   var_db_world_name=$DB_WORLD_NAME
   var_db_world_host=$DB_WORLD_HOST
   var_db_chars_name=$DB_CHARACTERS_NAME
   var_db_chars_host=$DB_CHARACTERS_HOST

   # ACSCS directories ---------------------------------------------------------
   # Current script filename and path
   local script_file=$(realpath -s "$0")
   var_script_path=$(dirname "$script_file")
   # Alternative solution to get current script path:
   #  var_script_path="$( cd -- "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
   # ACSCS base directory
   var_dir_base=${var_script_path%/*/*} # Remove the last 3 subdirs (acscs and scripts) from the current script's path.
      console_log_value "$var_dir_base" "$cons_lit_base_directory"
   # AzerothCore sources directory
   var_dir_sources="$var_dir_base/azerothcore"
   # Servers directory
   var_dir_server="$var_dir_base/server"
   # Scripts directory
   var_dir_scripts="$var_dir_base/scripts"
   # Logs directory
   var_dir_logs="$var_dir_base/logs"
   # Data directory
   var_dir_data="$var_dir_base/data"
   # Docs directory
   var_dir_docs="$var_dir_base/docs"
   # Sounds directory
   var_dir_sounds="$var_dir_base/media/sounds"
   # Temp directory
   var_dir_temp="$var_dir_base/temp"
   # Backup directories (must not end with "/")
   var_dir_backup_local="$var_dir_base/backup"
   var_dir_backup_remote="$REMOTE_BACKUPS_DIR"

   # Maintenance ---------------------------------------------------------------

   # MariaDB/MySQL process name
   var_db_process="mariadbd"

   # Session names for "screen". These could be constants, but I'll keep them here.
   var_session_auth="scr_auth"
   var_session_world="scr_world"

   # Should backups be copied to a remote directory?
   var_user_backup_remote=$REMOTE_BACKUPS

   # Number of cores used to compile the sources. Use all =)
   # var_compiler_cores=$(nproc)
   var_compiler_cores=$CPU_CORES

   # Get the sources hash, if any.
   var_achash=
   vars_get_achash

   var_internal_ip=
   var_external_ip=
   # vars_get_ips # Not yet. We'll get them just before showing the menu.

   var_pidof_auth=            # Updated in update_pidof_as
   var_pidof_worldserver=     # Updated in update_pidof_ws
   var_pidof_db=              # Updated in update_pidof_db
   var_answer=                # Used by read_answer as result
   var_confirmed=             # Used by read_confirmation as result

   # The sources have been successfully compiled.
   var_sources_just_compiled=
}

# ------------------------------------------------------------------------------
# Stores the current AzerothCore sources Github hash in "$var_achash".
# ------------------------------------------------------------------------------
function vars_get_achash ()
{
   if [ -d "$var_dir_sources" ]; then
      cd $var_dir_sources
      var_achash=$(git log --pretty=format:'%h' -n 1);
   fi
   if [[ $var_achash = "" ]]; then
      var_achash="-none-"
   fi
}

# ------------------------------------------------------------------------------
# Gets the internal and external ip's and stores them in "$var_internal_ip" and
# "$var_external_ip".
# ------------------------------------------------------------------------------
function vars_get_ips ()
{
   var_internal_ip=$(hostname -I)
   var_external_ip=$(dig +short myip.opendns.com @resolver4.opendns.com)
#  var_external_ip=$(curl -s http://whatismyip.akamai.com/) # This one requires curl package.
}

# ------------------------------------------------------------------------------
# Updates the PID of the MariaDB/MySQL daemon process in "$var_pidof_db".
# ------------------------------------------------------------------------------
function update_pidof_db ()
{
   var_pidof_db=$(pidof $var_db_process)
}

# ------------------------------------------------------------------------------
# Updates the PID of the AuthServer process in "$var_pidof_auth".
# ------------------------------------------------------------------------------
function update_pidof_as ()
{
   var_pidof_auth=$(pidof authserver)
}

# ------------------------------------------------------------------------------
# Updates the PID of the WorldServer process in "$var_pidof_worldserver".
# ------------------------------------------------------------------------------
function update_pidof_ws ()
{
   var_pidof_worldserver=$(pidof worldserver)
}

