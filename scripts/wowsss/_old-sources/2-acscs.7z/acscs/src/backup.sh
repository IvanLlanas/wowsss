# ------------------------------------------------------------------------------
# function acscs_backup_databases ()
# function acscs_backup_servers   ()
# function acscs_backup_sources   ()
# function acscs_backup_data      ()
# function acscs_backup_all       ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Compresses
#    $1: archive filename
#    $2: files to compress
#    $3: Options (If options="delete" source files are deleted after
#        compression)
# ------------------------------------------------------------------------------
function _compress ()
{
   local fullfilename=$1
   local files=$2
   local options=$3

   if [[ $options = "delete" ]]; then options="-sdel"
   fi
   7z a $fullfilename -t7z -mx=9 $options $files
}

# ------------------------------------------------------------------------------
# Copies the file specified in the first parameter ($1) to the remote backup
# directory ($var_dir_backup_remote) if $var_user_backup_remote is true.
# ------------------------------------------------------------------------------
function _copy_to_remote_backup ()
{
   if [ $var_user_backup_remote -gt 0 ]
      then
      local fullfilename=$1
      local filename=$(basename -- "$fullfilename")
      #extension="${filename##*.}"
      #filename="${filename%.*}"
      show_info_message "$cons_msg_copying_to_remote_: "$_bold1"$filename"$_bold2"..."
      rsync --progress $fullfilename $var_dir_backup_remote
   fi
}

# ------------------------------------------------------------------------------
# Menu options: "Save world database" and "Save auth and characters databases"
#               depending on $1 value ("world").
# ------------------------------------------------------------------------------
function acscs_backup_databases ()
{
   local world=$(expr "$1" == "world")
   local files=
   local sufix=
   local filename=
   local fullfilename=

   cd $var_dir_backup_local

   if [ $world -gt 0 ]
      then
      acscs_function_start "$cons_option_backup_databases_world"
      files="acore_world.sql"
      sufix="_databases_world"
      show_info_message "$cons_lit_extracting "$_bold1"acore_world"$_bold2"..."
      mysqldump --user=$var_db_user --password=$var_db_pass acore_world > acore_world.sql
   else
      acscs_function_start "$cons_option_backup_databases"
      files="acore_auth*.sql acore_characters*.sql"
      sufix="_databases_auth_chars"
      show_info_message "$cons_lit_extracting "$_bold1"acore_auth"$_bold2"..."
      mysqldump --user=$var_db_user --password=$var_db_pass acore_auth > acore_auth.sql
      show_info_message "$cons_lit_extracting "$_bold1"acore_characters"$_bold2"..."
      mysqldump --user=$var_db_user --password=$var_db_pass acore_characters > acore_characters-full.sql
      mysqldump --user=$var_db_user --password=$var_db_pass acore_characters > acore_characters-structure.sql --no-data
      mysqldump --user=$var_db_user --password=$var_db_pass acore_characters > acore_characters-data.sql      --no-create-info
   fi
   show_info_message "$cons_msg_compressing"
   filename=$(date +"%Y-%m-%d_%H-%M-%S")$sufix.7z
   fullfilename=$var_dir_backup_local/$filename
   _compress "$fullfilename" "$files" "delete"
   _copy_to_remote_backup "$fullfilename"

   acscs_function_end
}


# ------------------------------------------------------------------------------
# Menu option: Save servers files (binaries, data directory and sources excluded)
# ------------------------------------------------------------------------------
function acscs_backup_servers ()
{
   acscs_function_start "$cons_option_backup_servers"

   show_info_message "$cons_msg_compressing"
   cd $var_dir_base
   touch backup/.0 logs/.0 data/.0 temp/.0
   cd ..
   local filename=$(date +"%Y-%m-%d_%H-%M-%S")_servers.7z
   local fullfilename=$var_dir_backup_local/$filename
   _compress "$fullfilename" "wotlk/backup/.0 wotlk/data/.0 wotlk/logs/.0 wotlk/temp/.0 wotlk/media/* wotlk/scripts/* wotlk/server/etc/* wotlk/docs/*"
   _copy_to_remote_backup "$fullfilename"

   acscs_function_end
}

# ------------------------------------------------------------------------------
# Menu option: Save current AzerothCore sources.
# ------------------------------------------------------------------------------
function acscs_backup_sources ()
{
   acscs_function_start "$cons_option_backup_sources"

   show_info_message "$cons_msg_cleaning"
   cd $var_dir_sources/build
   make clean

   show_info_message "$cons_msg_compressing"
   cd $var_dir_base
   local filename="$(date +"%Y-%m-%d_%H-%M-%S")_sources-($var_achash).7z"
   local fullfilename=$var_dir_backup_local/$filename
   _compress "$fullfilename" "azerothcore/. server/etc/*"
   _copy_to_remote_backup "$fullfilename"

   acscs_function_end
}

# ------------------------------------------------------------------------------
# Menu option: Save data directory
# ------------------------------------------------------------------------------
function acscs_backup_data ()
{
   acscs_function_start "$cons_option_backup_data"

   show_info_message "$cons_lit_compressing "$_bold1"data"$_bold2"..."
   cd $var_dir_base
   local filename=$(date +"%Y-%m-%d_%H-%M-%S")_data.7z
   local fullfilename=$var_dir_backup_local/$filename
   _compress "$fullfilename" "data/*"
   _copy_to_remote_backup "$fullfilename"

   acscs_function_end
}

# ------------------------------------------------------------------------------
# Menu option: Save all (data directory and world database excluded)
# ------------------------------------------------------------------------------
function acscs_backup_all ()
{
   acscs_function_start "$cons_option_backup_all"
      # acscs_backup_databases "world"
      acscs_backup_databases
      acscs_backup_servers
      acscs_backup_sources
   acscs_function_end
   play_sound "$cons_snd_done1"
}
