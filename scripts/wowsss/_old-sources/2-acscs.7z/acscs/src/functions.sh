# ------------------------------------------------------------------------------
# function wait ()
# function show_fatal_error ()
# function show_error_message ()
# function show_warning_message ()
# function show_info_message ()

# function console_log_value ()
# function console_log_text ()

# function show_running_state ()
# function acscs_function_start ()
# function acscs_function_end_no_wait ()
# function acscs_function_end ()

# function read_answer ()
# function read_confirmation ()

# function play_sound ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Waits for $1 seconds (default "cons_wait_seconds").
# ------------------------------------------------------------------------------
function wait ()
{
   local seconds=$1
   if [[ $seconds -gt 0 ]]; then
      :
   else
      seconds=$cons_wait_seconds
   fi
   sleep $seconds
}

# ------------------------------------------------------------------------------
#  TEXT AND FORMAT FUNCTIONS ---------------------------------------------------
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Forces $COLUMNS update. It seems to work but I don't know why.
# ------------------------------------------------------------------------------
function _update_screen_columns ()
{
   local x=$COLUMNS
   sleep 0 # This sleep makes $COLUMNS get its proper value. Why? Dunno.
}

# ------------------------------------------------------------------------------
# Reports a fatal error message ($1) on the console and halts the script.
# ------------------------------------------------------------------------------
function show_fatal_error ()
{
   local msg=$1
   msg=${msg//$_bold1/$_ansi_yellow}
   msg=${msg//$_bold2/$_ansi_white}
   echo -e $_ansi_white$_ansi_bg_red"[ ${msg} $cons_msg_quitting ]"$_ansi_0
   wait
   exit
}

# ------------------------------------------------------------------------------
# Reports an error message ($1) on the console.
# ------------------------------------------------------------------------------
function show_error_message ()
{
   local msg=$1
   msg=${msg//$_bold1/$_ansi_yellow}
   msg=${msg//$_bold2/$_ansi_white}
   echo -e $_ansi_white$_ansi_bg_red"[ ${msg} ]"$_ansi_0
}

# ------------------------------------------------------------------------------
# Shows a warning message ($1) on the console. Full width.
# ------------------------------------------------------------------------------
function show_warning_message ()
{
   _update_screen_columns
   # Remove _boldx delimiters. No delimiter expected but just in case.
   local msg=$1
   local none=""
   msg=${msg//$_bold1/$none}
   msg=${msg//$_bold2/$none}

   # Calculate the filler size needed to fill the whole terminal width.
   local lmsg=${#msg}
   local count=$(($COLUMNS - $lmsg -2 -2))
   if [ $count -lt 1 ]
      then
      count=0
   fi
   local filler=$(head -c $count < /dev/zero | tr '\0' ' ' )

   msg=$1
   msg=${msg//$_bold1/$_ansi_red}
   msg=${msg//$_bold2/$_ansi_black}
   echo -e $_ansi_black$_ansi_bg_yellow"[ ${msg} ${filler}]"$_ansi_0
}

# ------------------------------------------------------------------------------
# Prints an information message ($1) on the console.
# ------------------------------------------------------------------------------
function show_info_message ()
{
   local msg=$1
   msg=${msg//$_bold1/$_ansi_yellow}
   msg=${msg//$_bold2/$_ansi_white}
   echo -e $_ansi_white$_ansi_bg_blue"[ ${msg} ]"$_ansi_0
}

# ------------------------------------------------------------------------------
# Prints a value ($1) and an optional literal ($2) on the console.
# ------------------------------------------------------------------------------
function console_log_value ()
{
   local value="$_bold1$1$_bold2"
   local literal=$2
   local text=""
   if [[ $literal == "" ]]; then  text=$value
   else                           text="$literal: $value"
   fi
   text=${text//$_bold1/$_ansi_white}
   text=${text//$_bold2/$_ansi_0}
   echo -e $text
}

# ------------------------------------------------------------------------------
# Prints a raw text ($1) on the console.
# ------------------------------------------------------------------------------
function console_log_text ()
{
   local text=$1
   text=${text//$_bold1/$_ansi_white}
   text=${text//$_bold2/$_ansi_0}
   echo -e $text
}

# ------------------------------------------------------------------------------
# Writes a function start title. Full width.
# ------------------------------------------------------------------------------
function acscs_function_start ()
{
   _update_screen_columns
   local msg=$1

   # Remove _boldx delimiters. No delimiter expected but just in case.
   local none=""
   msg=${msg//$_bold1/$none}
   msg=${msg//$_bold2/$none}

   # Calculate the filler size needed to fill the whole terminal width.
   local lmsg=${#msg}
   local count=$(($COLUMNS - $lmsg -2 -2))
   if [ $count -lt 1 ]
      then
      count=0
   fi
   local filler=$(head -c $count < /dev/zero | tr '\0' ' ' )

   echo -e $_ansi_black$_ansi_bg_white"[ ${msg} ]${filler}"$_ansi_0
}

# ------------------------------------------------------------------------------
# Writes a function end title. Full width.
# ------------------------------------------------------------------------------
function acscs_function_end_no_wait ()
{
   acscs_function_start "$cons_lit_finished"
}
function acscs_function_end ()
{
   acscs_function_end_no_wait
   wait
}

# ------------------------------------------------------------------------------
# Writes [Running] or [Stopped] literals depending on the value (true/false) of
# the first parameter.
# ------------------------------------------------------------------------------
function show_running_state ()
{
   if [ $1 ]; then
      echo -en $_ansi_black$_ansi_bg_green"[ $cons_lit_running Running ]"$_ansi_0
   else
      echo -en $_ansi_black$_ansi_bg_red"[ $cons_lit_stopped ]"$_ansi_0
   fi
}

# ------------------------------------------------------------------------------
# Colored user input. Puts the user text into variable var_answer.
# ------------------------------------------------------------------------------
function read_answer ()
{
   echo -en $_input_color
   read var_answer
   echo -en $_ansi_0
}

# ------------------------------------------------------------------------------
# Prompt the user to type "ok" in order to confirm the operation especified in
# the first parameter. If confirmed (the user typed "ok") variable var_confirmed
# is true, false otherwise.
# ------------------------------------------------------------------------------
function read_confirmation ()
{
   local msg="$cons_msg_type_ok_to_"$_bold1"$1"$_bold2": "
   msg=${msg//$_bold1/$_ansi_yellow}
   msg=${msg//$_bold2/$_ansi_0}
   echo -en "$msg"
   read_answer
   if [[ $var_answer = "$cons_confirmation" ]]
      then
      var_confirmed=1
   else
      show_error_message "$cons_msg_not_confirmed"
      # This counts as "false".
      var_confirmed=
   fi
}

# ------------------------------------------------------------------------------
# function play_sound ()
# ------------------------------------------------------------------------------
function play_sound ()
{
   local filename=$1
   $cons_playsound $var_dir_sounds/$filename $cons_playsound_params &> /dev/null
}
