# ------------------------------------------------------------------------------
# function acscs_main_menu ()
#     function acscs_sources_download ()
#     function acscs_sources_compile ()
#     function acscs_sources_update ()
#     function acscs_restore_databases ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Restore screen session $1
# ------------------------------------------------------------------------------
function _screen_restore_session ()
{
   local session=$1
   acscs_function_start "Restoring session \"$session\"... Press <b>Ctrl+A</b>, <b>Ctrl+D</b> to return."
   screen -r $session
   acscs_function_end_no_wait
}

# ------------------------------------------------------------------------------
# Updates start_enabled, stop_enabled, backup_enabled, make_enabled and
# source_enabled_* colours for menu/command line help. It also fixes the prefixes
# for the compile/update/download options.
# ------------------------------------------------------------------------------
function _update_menu_colors ()
{
   # Check servers PID's
   update_pidof_as
   update_pidof_ws

   if [ $var_pidof_auth ] && [ $var_pidof_auth ]
      then
      start_enabled=$_disabled_color
   else
      start_enabled=$_menu_text_color
   fi

   prefix_src_update=" "
   prefix_src_download=" "
   prefix_src_make=" "
   prefix_src_install=" "

   if [ $var_pidof_auth ] || [ $var_pidof_worldserver ]
      then
      # Colors
      stop_enabled=$_menu_text_color
      backup_enabled=$_disabled_color
      make_enabled=$_disabled_color
      install_enabled=$_disabled_color
      source_enabled_download=$_disabled_color
      source_enabled_update=$_disabled_color
   else
      # Colors
      stop_enabled=$_disabled_color
      backup_enabled=$_ansi_lime
      make_enabled=$_ansi_red
      install_enabled=$_ansi_red
      source_enabled_download=$_ansi_yellow
      source_enabled_update=$_ansi_yellow
   fi
}

# ------------------------------------------------------------------------------
# Enters the menu mode of the script.
function acscs_main_menu ()
{
   local d=$_ansi_white
   local i="   "
   local i2="  "
   local filename="$var_dir_docs/welcome.txt"
   local text=

   while [ true ]
   do
      _update_menu_colors


      if [ ! -f "$filename" ]; then
	 text=$(server_version_no_date)
      else
         text=$(head --lines=1 "$filename")
      fi

      acscs_function_start "$text"

      # Paint the menu
      echo ""
      echo -en "    AuthServer: "
      show_running_state $var_pidof_auth
      echo -e "        $cons_lit_internal_ip: $_ansi_white$var_internal_ip$_ansi_0"
      echo -en "   WorldServer: "
      show_running_state $var_pidof_worldserver
      echo -e "        $cons_lit_external_ip: $_ansi_yellow$var_external_ip$_ansi_0"
      echo ""
      echo "$cons_msg_choose_an_option"
      echo ""

      echo -e "${i}$d""1"$_ansi_0") "$start_enabled$cons_option_start_server$_ansi_0
      echo -e "${i}$d""2"$_ansi_0") "$stop_enabled$cons_option_stop_server$_ansi_0
      echo -e "${i}$d""3"$_ansi_0") "$stop_enabled$cons_option_process_monitor$_ansi_0 "${i}${i}${i}${i}" $d"V"$_ansi_0"/"$d"W"$_ansi_0") "$stop_enabled$cons_option_restore_consoles$_ansi_0
      echo ""
      echo -e "${i}$d""4"$_ansi_0") "$backup_enabled$cons_option_backup_databases$_ansi_0
      echo -e "${i}$d""5"$_ansi_0") "$backup_enabled$cons_option_backup_databases_world$_ansi_0
      echo -e "${i}$d""6"$_ansi_0") "$backup_enabled$cons_option_backup_servers$_ansi_0
      echo -e "${i}$d""7"$_ansi_0") "$backup_enabled$cons_option_backup_sources$_ansi_0
      echo -e "${i}$d""8"$_ansi_0") "$backup_enabled$cons_option_backup_all$_ansi_0
      echo -e "${i}$d""9"$_ansi_0") "$backup_enabled$cons_option_backup_data$_ansi_0
      echo -e "${i}$d""R"$_ansi_0") "$make_enabled$cons_option_restore_databases$_ansi_0
      echo ""
      echo -e "${i2}${prefix_src_download}$d""D"$_ansi_0") "$source_enabled_download$cons_option_sources_download$_ansi_0
      echo -e   "${i2}${prefix_src_update}$d""U"$_ansi_0") "$source_enabled_update$cons_option_sources_update$_ansi_0
      echo ""
      echo -e     "${i2}${prefix_src_make}$d""C"$_ansi_0") "$make_enabled$cons_option_sources_compile$_ansi_0
      echo ""
      echo -e "${i}$d""Q"$_ansi_0") "$_menu_text_color"Quit"$_ansi_0
      echo ""
      echo -n "$cons_msg_enter_option"
      read_answer
      case $var_answer in
       "1")   acscs_servers_start;;
       "2")   acscs_servers_stop;;
       "3")   acscs_top;;
       "V")   _screen_restore_session "$var_session_auth";;
       "W")   _screen_restore_session "$var_session_world";;
       "4")   acscs_backup_databases;;
       "5")   acscs_backup_databases "world";;
       "6")   acscs_backup_servers;;
       "7")   acscs_backup_sources;;
       "8")   acscs_backup_all;;
       "9")   acscs_backup_data;;
       "R")   acscs_restore_databases;;
       "D")   acscs_sources_download;;
       "U")   acscs_sources_update;;
       "C")   acscs_sources_compile;;
       "Q")   show_info_message "$cons_msg_good_bye";
              exit;;
         *)   show_error_message "$cons_msg_error_invalid_option_\"$_bold1$var_answer$_bold2\".";;
      esac
   done
}

# ------------------------------------------------------------------------------
# Menu option: Restore databases
function acscs_restore_databases ()
{
   ensure_no_server_running
   if [ $var_no_server_running ]
      then
      show_warning_message ""
      show_warning_message "<b>WARNING</b>: This process will try to restore old databases from its scripts:"
      show_warning_message "         Database <b>acore_auth</b> will be restored from script <b>acore_auth.sql</b>."
      show_warning_message "         Database <b>acore_characters</b> will be restored from script <b>acore_characters-full.sql</b>."
      show_warning_message "         Database <b>acore_world</b> will be restored from script <b>acore_world.sql</b>."
      show_warning_message "         Scripts must be placed in \"<b>$var_dir_scripts/sql</b>\"."
      show_warning_message ""
      read_confirmation "$cons_option_restore_databases"
      if [ $var_confirmed ]
         then
         acscs_function_start "$cons_option_restore_databases"

         cd $var_dir_scripts/sql

         show_info_message "Importing \"<b>acore_auth</b>\" database:"
         if test -f "acore_auth.sql"; then
            mysql -u $var_db_user -p acore_auth       < acore_auth.sql
         else
            show_error_message "File <b>acore_auth.sql</b> not found."
         fi

         show_info_message "Importing \"<b>acore_characters</b>\" database:"
         if test -f "acore_characters-full.sql"; then
            mysql -u $var_db_user -p acore_characters < acore_characters-full.sql
         else
            show_error_message "File <b>acore_characters-full.sql</b> not found."
         fi

         show_info_message "Importing \"<b>acore_world</b>\" database:"
         if test -f "acore_world.sql"; then
            mysql -u $var_db_user -p acore_world      < acore_world.sql
         else
            show_error_message "File <b>acore_world.sql</b> not found."
         fi

         acscs_function_end
      fi
   fi
}

# ------------------------------------------------------------------------------
# Menu option: Compile servers and tools
# ------------------------------------------------------------------------------
function acscs_sources_compile ()
{
   ensure_no_server_running
   if [ $var_no_server_running ]
      then
      read_confirmation "$cons_option_sources_compile"
      if [ $var_confirmed ]
         then
         acscs_function_start "$cons_option_sources_compile"
         azerothcore_sources_compile_and_install
         acscs_function_end
      fi
   fi
}

# ------------------------------------------------------------------------------
# Menu option: Remove current sources and download them from github
#              The source is prepared for compilation process creating the
#              make files (cmake).
# ------------------------------------------------------------------------------
function acscs_sources_download ()
{
   read_confirmation "$cons_option_sources_download"
   if [ $var_confirmed ]
      then
      acscs_function_start "$cons_option_sources_download"
      azerothcore_sources_download
      acscs_function_end
   fi
}

# ------------------------------------------------------------------------------
# Menu option: Update current sources from github
# ------------------------------------------------------------------------------
function acscs_sources_update ()
{
   read_confirmation "$cons_option_sources_update"
   if [ $var_confirmed ]
      then
      acscs_function_start "$cons_option_sources_update"
      azerothcore_sources_update
      acscs_function_end
   fi
}

