# ------------------------------------------------------------------------------
# function initial_check_required_packages   ()
# function initial_check_azerothcore_sources ()
# function initial_check_databases           ()
# function initial_check_data_files          ()
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Checks if all packages in $1 are installed. If any package is missing it
# will be installed.
# $2 is the heading message.
# Quits on error.
# ------------------------------------------------------------------------------
function _check_packages ()
{
   local packages="$1"
   local msg="$2"

   acscs_function_start "$msg"

   # https://byby.dev/bash-split-string
   # Accept current IFS and use array assignment.
   packages_array=($packages)
   for package in "${packages_array[@]}"
   do
      echo -ne "  [ ] $_ansi_yellow$package$_ansi_0"
      package_installed=$(dpkg-query -W --showformat='${Status}\n' $package 2>/dev/null |grep "install ok installed")
      if [ "" = "$package_installed" ]; then
      echo ""
         sudo apt-get --yes install $package | sed 's/^/      /'
         # if [[ $? > 0 ]]
         if [[ ${PIPESTATUS[0]} -gt 0 ]]; then
            show_fatal_error "$cons_msg_installation_failed"
         else
            ((var_installed_packages=var_installed_packages+1))
         fi
      else
         echo -e "\r  [x] $package"
      fi
   done
   show_info_message "$cons_msg_done"
}

# ------------------------------------------------------------------------------
# Checks ACSCS and AzerothCore required packages are installed.
# If any package is missing it will be installed. Quits on error.
# ------------------------------------------------------------------------------
function initial_check_required_packages ()
{
   local packages="$cons_acscs_packages"

   _check_packages "$packages" "$cons_msg_checking_acscs_req_packages"
   if [ -n "$var_os_is_ubuntu" ]; then packages=$cons_ac_packages_ubuntu
   else                                packages=$cons_ac_packages_debian
   fi
   _check_packages "$packages" "$cons_msg_checking_ac_req_packages"

   if [[ $var_installed_packages -gt 0 ]]; then
      show_warning_message "$cons_lit_installed_packages: $var_installed_packages"
   fi
}

# ------------------------------------------------------------------------------
# Checks if the AzerothCore sources are missing. In such case it downloads them.
# Quits on error.
# ------------------------------------------------------------------------------
function initial_check_azerothcore_sources ()
{
   acscs_function_start "$cons_msg_checking_ac_sources"
   if [[ -f $var_dir_bin/authserver && -f $var_dir_bin/worldserver ]]; then
      show_info_message "$cons_msg_binaries_found"
      servers_setup_default_config_files
   elif test -f $var_dir_sources/build/Makefile; then
      show_info_message "$cons_msg_done"
      servers_setup_default_config_files
   else
      azerothcore_sources_download 1 # Quit on error
      # If we get here then the sources were downloaded.
      azerothcore_sources_compile_and_install
   fi
}

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
function initial_check_databases ()
{
   acscs_function_start "$cons_msg_checking_databases"
   database_check_enable_admin_access
   database_check_create_servers_access
   databases_check_create
}

# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
function initial_check_data_files ()
{
   acscs_function_start "$cons_msg_checking_data"
#  /home/ivan/wotlk/data/maps/0004331.map

   if test -d "$var_dir_data/maps"; then
      if test -d "$var_dir_data/mmaps"; then
         if test -d "$var_dir_data/vmaps"; then
            local count=$(find $var_dir_data -type f | wc -l)
            if [ $count -gt 20000 ]; then
               show_info_message "$cons_msg_done"
               return
            fi
         fi
      fi
   fi

   local filename=$var_dir_temp/data.zip
   # 900 seconds timeout is crazy.
   wget --output-document="$filename" --timeout=30 "$cons_ac_data_url"
   result=$?
   if [ $result -ne 0 ]; then
      show_fatal_error "$cons_msg_error_download_data"
   fi
   unzip "$filename" -d "$var_dir_data"
   result=$?
   rm "$filename"
   if [ $result -ne 0 ]; then
      show_fatal_error "$cons_msg_error_extracting_data"
   fi
   show_info_message "$cons_msg_done"
}

