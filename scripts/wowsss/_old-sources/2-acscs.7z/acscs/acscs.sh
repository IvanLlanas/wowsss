# ------------------------------------------------------------------------------
# Pending:
# Check if it is first time to advice about editting settings.sh
#     "It seems this is the first time...."
# enabled/disabled colors in menu
# sources check should check als binaries to force compile
# colors in menu

# ------------------------------------------------------------------------------
# AzerothCore Server Command Script
# (C) Copyright by Ivan Llanas, 2022-23
# ------------------------------------------------------------------------------
# This script performs all the functions related to AzerothCore "World of
# Warcraft - Wrath of the Lich King" server installation and maintenance on a
# Ubuntu or Debian system.
# ------------------------------------------------------------------------------
# Versions
# ------------------------------------------------------------------------------
# 3.0 - 2023/07/xx - Added package requirements and database installation and
#                    configuration.
#                    Source fragmented into several modules (scripts).
# ------------------------------------------------------------------------------
# 2.6 - 2023/06/15 - Added Debian support to machine names.
#                    Cmake command line updated.
#                    Wait added after unknown machine type error.
#                    When getting the AzerothCore hash a directory check is
#                    performed and a default value assigned on errors.
#                    F200CA machines addedd.
# 2.5 - 2023/05/06 - AzerothCore git hash is now updated after compiling and
#                    updated correctly.
# 2.4 - 2023/04/01 - "Save all databases" is now "Save world database"
#                    AzerothCore hash added to sources archive filename.
# 2.3 - 2023/03/17 - "Save all" will no longer save world database.
#                    AzerothCore hash added to welcome.txt and history.txt.
# 2.2 - 2023/03/13 - Replaced gnome-terminal by screen for servers consoles.
#                    Some variables changed for coherence.
# 2.1 - 2023/01/10 - Added prefixes (symbols) and colors depending on
#                    download/update/compile state.
# 2.0 - 2022/12/18
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# Loads all the ACSCS modules.
# ------------------------------------------------------------------------------
function include_modules ()
{
   local filename=$(realpath -s "$0")
   local path=$(dirname "$filename")

   source "$path/settings.sh"
   source "$path/src/constants.sh"
   source "$path/src/variables.sh"
   source "$path/src/functions.sh"
   source "$path/src/installation.sh"
   source "$path/src/servers.sh"
   source "$path/src/sources.sh"
   source "$path/src/databases.sh"
   source "$path/src/backup.sh"
   source "$path/src/menu.sh"
}

# ------------------------------------------------------------------------------
# Checks all the requirements and installs whatever is needed.
# ------------------------------------------------------------------------------
function check_server_installation ()
{
   initial_check_required_packages
   initial_check_azerothcore_sources
   initial_check_data_files
   initial_check_databases
}

# ------------------------------------------------------------------------------
#  MAIN FUNCTION ---------------------------------------------------------------
# ------------------------------------------------------------------------------
function main ()
{
   # We want case-insensitive comparisons.
   shopt -s nocasematch

   include_modules
   declare_constants
   declare_variables
   declare_constants_var_dependent_on_variables
   check_server_installation

   vars_get_ips # We'll only get the IP's for menu mode and only once.
   acscs_main_menu
}

# Let's go.
main
